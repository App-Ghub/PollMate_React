const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');
const cors = require('cors');

const app = express();
const db = new Database('polls.db');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../client/build')));

// Ensure poll table exists
db.prepare(`CREATE TABLE IF NOT EXISTS polls (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT,
  options TEXT,
  votes TEXT,
  date TEXT
)`).run();

const today = new Date().toISOString().split('T')[0];
const existingPoll = db.prepare("SELECT * FROM polls WHERE date = ?").get(today);
if (!existingPoll) {
  db.prepare("INSERT INTO polls (question, options, votes, date) VALUES (?, ?, ?, ?)").run(
    "What's your favorite frontend framework?",
    JSON.stringify(["React", "Vue", "Angular", "Svelte"]),
    JSON.stringify([0, 0, 0, 0]),
    today
  );
}

// Get today's poll
app.get('/api/poll/today', (req, res) => {
  const poll = db.prepare("SELECT * FROM polls WHERE date = ?").get(today);
  res.json({
    question: poll.question,
    options: JSON.parse(poll.options),
    votes: JSON.parse(poll.votes)
  });
});

// Vote handler
app.post('/api/poll/vote', (req, res) => {
  const index = req.body.option;
  const poll = db.prepare("SELECT * FROM polls WHERE date = ?").get(today);
  const votes = JSON.parse(poll.votes);
  votes[index] += 1;
  db.prepare("UPDATE polls SET votes = ? WHERE date = ?").run(JSON.stringify(votes), today);
  res.json({ success: true });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));